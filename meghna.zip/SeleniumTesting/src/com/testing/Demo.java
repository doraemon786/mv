package com.testing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Demo {

	
	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\Sourab\\Desktop\\selenium\\chromedriver.exe");
	WebDriver driver= new ChromeDriver();
	driver.get("http://dna1-staging.mcdonalds.com/wws/json/getCategoryDetails.htm?country=se&language=sv&categoryId=100025&specialCall=true&showLiveData=true");
	driver.get("http://dna1-staging.mcdonalds.com/wws/json/getCategoryDetails.htm?country=se&language=sv&categoryId=100025&specialCall=true&showLiveData=false");
	/*WebElement elm6=driver.findElement(By.name("q"));
	elm6.sendKeys("gmail");
	elm6.submit();
	WebElement elm1=driver.findElement(By.xpath("//*[@id='rso']/div[1]/div/div/div/div[1]/a/h3"));
	elm1.click();*/
	
	/*WebElement elm2=driver.findElement(By.xpath("//*[@id='view_container']/div/div/div[1]/div/div[2]/div/div[3]/svg"));
	Select sel=new Select(elm2);
	sel.selectByIndex(0);
	WebElement elm3=driver.findElement(By.xpath("//*[@id='view_container']/div/div/div[2]/div/div/div/form/content/section/div/content/div/div/ul/li[2]/div"));
	elm3.click();
	driver.findElement(By.xpath("//*[@id='identifierId']")).sendKeys("k.aggarwal108@gmail.com");
	driver.findElement(By.xpath("//*[@id='identifierNext']/content/span")).click();
	driver.findElement(By.xpath("//*[@id='password']/div[1]/div/div[1]/input")).sendKeys("9897168675k");
	driver.findElement(By.xpath("//*[@id='passwordNext']/content")).click();*/
	/*driver.close();*/
	}
}
